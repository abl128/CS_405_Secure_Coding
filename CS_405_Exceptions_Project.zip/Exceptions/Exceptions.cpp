// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Modified by Andrew Laipple for CS-405 Module Four

#include <iostream>

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw a standard exception
    throw std::exception("A very bad error occured!");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Try the do_even_more_custom_application_logic function
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception)
    {
        // The do_even_more_custom_application_logic function failed, 
        // inform the user of the particular failure.
        std::cerr << "Exception in do_even_more_custom_application_logic: " << exception.what() << std::endl;
    }

    // Even though the function does not contain an input, we will
    // use an invalid argument exception to test the logic
    throw std::invalid_argument("Invalid argument to do_custom_application_logic!");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Make sure the denominator is not 0, if it is throw an exception
    if (den == 0)
    {
        throw std::runtime_error("Attempt to Divide by Zero!");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;
    // Try the divide function
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& exception)
    {
        // The divide function failed, inform the user of the particular failure.
        std::cerr << "Exception in divide function: " << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Try to execute each function
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const std::invalid_argument& exception)
    {
        std::cerr << "Invalid Argument Exception: " << exception.what() << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cerr << "Standard Exception: " << exception.what() << std::endl;
    }
    catch (...)
    {
        // This will catch any exceptions that were not already handled above.
        std::cerr << "An unhandled exception occurred!" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
