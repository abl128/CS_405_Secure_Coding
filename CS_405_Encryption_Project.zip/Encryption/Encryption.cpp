// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Modified by Andrew Laipple for CS-405 Module 5

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // Use a XOR operation to transform each character of the input
        // based on the key. Use the modulus operator so that we
        // don't go beyond the bounds of the input key.
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    // Initialize the output text to something in case an error
    // occurs opening the file
    std::string file_text = "John Q. Smith\nThis is my test string";

    // Define variables for the input file, buffer the file will
    // be read into, and a string for each line read.
    std::string input_line;
    std::stringstream file_buf;
    std::ifstream input_file(filename);

    // First make sure the file was opened correctly
    if (input_file.is_open())
    {
        // Get each line of the file and place it into the buffer.
        while (std::getline(input_file, input_line))
        {
            // The getline function removes the newline, but since
            // we want to place everything into a std::string, add
            // the newline back in.
            file_buf << input_line << "\n";
        }

        // Done reading the file so make sure to close it
        input_file.close();

        // Now set the output string to the full file contents
        file_text = file_buf.str();
    }
    else
    {
        // The file could not be opened. Inform the user
        std::cerr << "File: " << filename << " could not be opened for input." << std::endl;
    }

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Define local variables for the timestamp and output file
    time_t seconds_since_epoch;
    tm local_time;
    std::ofstream output_file(filename);

    // First make sure the file was opened correctly
    if (output_file.is_open())
    {
        //  Output to file according to the following format
        //  Line 1: student name
        output_file << student_name << std::endl;

        //  Line 2: timestamp (yyyy-mm-dd).
        //   Get raw time then convert to local time
        time(&seconds_since_epoch);
        errno_t error = localtime_s(&local_time, &seconds_since_epoch);
        if (error)
        {
            // Shouldn't happen but since we are using local_time_s
            // we need to check for the error;
            std::cerr << "Invalid argument passed to function localtime_s" << std::endl;

            // exit the program.
            exit(1);
        }
        //   Use the puttime function to place into file in the proper format.
        output_file << std::put_time(&local_time, "%Y-%m-%d") << std::endl;

        //  Line 3: key used
        output_file << key << std::endl;

        //  Line 4+: data
        //   The data should contain newline characters already 
        output_file << data;

        // Done writing to the file so make sure to close it
        output_file.close();
    }
    else
    {
        // The file could not be opened. Inform the user
        std::cerr << "File: " << filename << " could not be opened for output." << std::endl;
    }
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
    // Lines 3+: <lorem ipsum generated with 3 paragraphs> 
    //  Fire in the hole bowsprit Jack Tar gally holystone sloop grog heave to grapple Sea Legs. Gally hearties case shot crimp spirits pillage galleon chase guns skysail yo-ho-ho. Jury mast coxswain measured fer yer chains man-of-war Privateer yardarm aft handsomely Jolly Roger mutiny.
    //  Hulk coffer doubloon Shiver me timbers long clothes skysail Nelsons folly reef sails Jack Tar Davy Jones' Locker. Splice the main brace ye fathom me bilge water walk the plank bowsprit gun Blimey wench. Parrel Gold Road clap of thunder Shiver me timbers hempen halter yardarm grapple wench bilged on her anchor American Main.
    //  Brigantine coxswain interloper jolly boat heave down cutlass crow's nest wherry dance the hempen jig spirits. Interloper Sea Legs plunder shrouds knave sloop run a shot across the bow Jack Ketch mutiny barkadeer. Heave to gun matey Arr draft jolly boat marooned Cat o'nine tails topsail Blimey.

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
