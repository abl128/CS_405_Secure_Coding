// Modified by Andrew Laipple for CS-405 Module Four

// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// This test to verify adding a single value to an empty collection
// This is a positive test.
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Make sure there is nothing in the collection.
    ASSERT_EQ(collection->size(), 0);

    // Add one entry
    add_entries(1);

    // Verify there is now a single entry in the collection
    ASSERT_EQ(collection->size(), 1);
}

// This test verifies adding five values to collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Make sure there is nothing in the collection.
    ASSERT_EQ(collection->size(), 0);

    // Add 5 entries
    add_entries(5);

    // Verify there is now a single entry in the collection
    ASSERT_EQ(collection->size(), 5);
}

// This test verifies that max size is greater than or equal to size for 0, 1, 5, 10 entries
// NOTE: This is a positive test.
TEST_F(CollectionTest, VerifyMaxSizeOfCollection)
{
    // Verify size is 0 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 0);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add 1 entry
    add_entries(1);

    // Verify size is 1 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 1);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add 4 more entrries
    add_entries(4);

    // Verify size is 5 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 5);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add 5 more entries
    add_entries(5);

    // Verify size is 10 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 10);
    ASSERT_GE(collection->max_size(), collection->size());
}

// This test verifies that capacity is greater than or equal to size for 0, 1, 5, 10 entries
// NOTE: This is a positive test.
TEST_F(CollectionTest, VerifyCapacityOfCollection)
{
    // Verify size is 0 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 0);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 1 entry
    add_entries(1);

    // Verify size is 1 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 1);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 4 more entrries
    add_entries(4);

    // Verify size is 5 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 5);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add 5 more entries
    add_entries(5);

    // Verify size is 10 and max size is greater than or equal to it.
    ASSERT_EQ(collection->size(), 10);
    ASSERT_GE(collection->capacity(), collection->size());
}

// This test verifies resizing increases the collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    // Make sure there is nothing in the collection.
    EXPECT_EQ(collection->size(), 0);

    // Resize the collection to 1
    collection->resize(1, 0);

    // Verify there is now a single entry in the collection
    ASSERT_EQ(collection->size(), 1);
}

// This test verifies resizing decreases the collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    add_entries(5);

    // Make sure there are five entries in the collection.
    EXPECT_EQ(collection->size(), 5);

    // Resize the collection to 1
    collection->resize(1);

    // Verify there is now a single entry in the collection
    ASSERT_EQ(collection->size(), 1);
}

// This test verifies resizing decreases the collection to zero
// NOTE: This is a positive test.
TEST_F(CollectionTest, ResizeCollectionToZero)
{
    add_entries(5);

    // Make sure there are five entries in the collection.
    EXPECT_EQ(collection->size(), 5);

    // Resize the collection to 1
    collection->resize(0);

    // Verify the collection is now empty
    ASSERT_EQ(collection->size(), 0);
}

// This test verifies clear erases the collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add an entry to the collection
    add_entries(1);

    // Make sure there is something in the collection before clearing
    // Use expect instead of assert since this isn't the purpose of 
    // the test, but we need it to be true for the ASSERT to verify
    // the proper thing.
    EXPECT_GT(collection->size(), 0);

    // Now clear the collection
    collection->clear();

    // Verify there is now no entries in the collection
    ASSERT_EQ(collection->size(), 0);
}

// This test verifies erase(begin,end) erases the collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, EraseErasesCollection)
{
    // Add 5 entries to the collection
    add_entries(5);

    // Make sure there is something in the collection before clearing
    // Use expect instead of assert since this isn't the purpose of 
    // the test, but we need it to be true for the ASSERT to verify
    // the proper thing.
    EXPECT_EQ(collection->size(), 5);

    // Now erase the collection
    collection->erase(collection->begin(), collection->end());

    // Verify there is now no entries in the collection
    ASSERT_EQ(collection->size(), 0);
}

// This test verifies reserve increases the capacity but not the size of the collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSizeOfCollection)
{
    // Make sure the collection is empty.
    ASSERT_EQ(collection->size(), 0);

    // Reserve 1 entry in the collection
    collection->reserve(1);

    // Verify size is 0, but capacity is 1
    ASSERT_EQ(collection->size(), 0);
    ASSERT_EQ(collection->capacity(), 1);
}

// This test verifies the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeExceptionWithAt)
{
    // Make sure there is nothing in the collection.
    EXPECT_EQ(collection->size(), 0);

    // Verify an exception occurs when using At with a bad index
    ASSERT_THROW(int value = collection->at(1), std::out_of_range);
}

// This test verifies that an assert occurs if add entries is called and 0 is passed as an argument.
// NOTE: This is a negative test
TEST_F(CollectionTest, AssertWhenAddingZeroEntries)
{
    // Verify an assert occurs if trying to add 0 entries to the collection
    ASSERT_DEATH(add_entries(0), ".*");
}

// This test verifies the insert function increases the size of the collection
// NOTE: This is a positive test.
TEST_F(CollectionTest, InsertIncreasesSizeOfCollection)
{
    // Make sure the collection is empty.
    ASSERT_EQ(collection->size(), 0);

    // Insert an entry in the collection
    collection->insert(collection->begin(), 1);

    // Verify size is now 1
    ASSERT_EQ(collection->size(), 1);
}
